import React ,{Component} from 'react';
import {Button} from 'antd';

//const FamilyContext = React.createContext({})
const FamilyContext = React.createContext({});

export default class TestContext extends Component {
    
    
    
    render(){
        
        return(
        <div>
            GiBi Balaji gethu Rajesh Giribaalji Dosa masala
           <Button>R.Giri balaji</Button>
        </div>
            
        );
    }
} 