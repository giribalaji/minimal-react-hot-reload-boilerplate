import React from 'react';
import ReactDOM from 'react-dom';
import TestContext from './TestContext';

const title = 'GiriBalaji and syed ghgh vbhvhvjn Sridhar sampath My Minimal React Webpack Babel Setup';

ReactDOM.render(<TestContext />,
  document.getElementById('app')
);

module.hot.accept();