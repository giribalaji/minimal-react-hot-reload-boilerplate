var path = require('path');
const webpack = require('webpack');

module.exports = {
  entry: [
    'webpack-hot-middleware/client',
    './src/index'
  ],
      plugins: [
    new webpack.HotModuleReplacementPlugin()
  ],
  devtool: false,
  module: {
 /*   rules: [
      {
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        use: ['react-hot-loader','babel-loader']
      }
    ]
  },*/
    rules: [{
      test: /\.js$/,
      use: ['babel-loader'],
      include: path.join(__dirname, 'src')
    },
      {
      test:/\.css$/,
      use: ['style-loader', 'css-loader']
      },
      {
      test:/\.less$/,
      use: ['style-loader', 'css-loader','less-loader']
      }      
              ]
    },
  resolve: {
    extensions: ['*', '.js', '.jsx']
  },
  output: {
    path: path.join(__dirname, 'dist'),
      //__dirname + '/dist',
    publicPath: '/',
    filename: 'bundle.js'
  },

 /* devServer: {
    contentBase: './dist',
 //   hot: true
  }*/
};
